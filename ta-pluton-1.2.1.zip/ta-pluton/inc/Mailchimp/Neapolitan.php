<?php

class Mailchimp_Neapolitan {
    public function __construct(Mailchimp $master) {
        $this->master = $master;
    }

}


