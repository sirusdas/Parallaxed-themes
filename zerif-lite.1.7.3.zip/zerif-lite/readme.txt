=== Zerif Lite ===
Contributors:		codeinwp
Tags:				black, gray, red, white, one-column, two-columns, right-sidebar, responsive-layout, custom-background, custom-menu, editor-style, featured-images, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		4.0

Zerif Lite
== Description ==
Zerif Lite is a modern responsive Wordpress Theme. It's perfect for web agencies, digital studios, corporate, product showcase, personal and business portfolio.

= License =
Zerif Lite WordPress theme, Copyright (C) 2014 ThemeIsle.com
Zerif Lite WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows:

* Bootstrap v3.1.1 (http://getbootstrap.com)
    Copyright 2011-2014 Twitter, Inc.
    Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* jQuery Knob
    Copyright (c) 2012 Anthony Terrien
    Under MIT and GPL licenses.

* jQuery One Page Nav Plugin
    Copyright (c) 2010 Trevor Davis (http://trevordavis.net)
    Dual licensed under the MIT and GPL licenses.

* jquery.scrollTo.js
    Copyright (c) 2007-2013 Ariel Flesler - aflesler<a>gmail<d>com | http://flesler.blogspot.com
    Dual licensed under MIT and GPL.

* jQuery Vegas
     Copyright (C) 2010-2013 Jay Salvat - http://jaysalvat.com/
     Licensed under the MIT license.

 * scrollReveal.js
     Copyright (C) 2014  https://twitter.com/julianlloyd
     Licensed under the MIT license.

 * images/bg.jpg
    Copyright (C) 2014 http://jaymantri.com/
	
 * images/focus.png
    Copyright (C) 2014 https://www.iconfinder.com/icons/283043/album_cloud_frame_gallery_image_mountain_painting_photo_photos_pictures_sky_icon

 * Font Awesome is fully open source and is GPL friendly. You can use it for commercial projects, open source projects, or really just about whatever you want.
   http://fortawesome.github.io/Font-Awesome/license/